Code inspired by the tutorial : https://brennan.io/2015/01/16/write-a-shell-in-c/

Nathan Marcotte 
V00876934
CSC 360 : Spring 2019
Kapish